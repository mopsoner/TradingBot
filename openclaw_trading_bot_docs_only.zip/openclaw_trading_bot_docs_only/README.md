# OpenClaw SMC/Wyckoff Trading Bot — Docs-Only Scaffold

This package contains the **non-code project files** needed to generate your OpenClaw trading bot with Codex.

It is designed for a bot that trades **ETHUSDT / BTCUSDT** using only this signal model:

1. Liquidity zone
2. Liquidity sweep
3. Spring or UTAD
4. Displacement
5. Break of Structure (BOS)
6. Fibonacci retracement entry
7. Expansion to next liquidity

## Included
- `AGENTS.md`
- Agent docs and prompts
- `SKILL.md` files for each module
- JSON config and schema placeholders
- Cron templates
- Research / paper / live workflow docs
- Risk and journaling specifications

## Not included
- No Python / TypeScript / JS code
- No exchange execution code
- No data fetcher implementation
- No backtest engine implementation

## Recommended workflow
1. Copy these files into your OpenClaw project root.
2. Merge with your existing template if needed.
3. Ask Codex to implement the code according to these files.
4. Start with research mode, then paper mode, then live mode.

## Core rule
No trade is valid unless all of these exist:
- liquidity zone
- sweep
- Spring or UTAD
- displacement
- BOS
- Fibonacci retracement entry

## Modes
- Research
- Paper
- Live
